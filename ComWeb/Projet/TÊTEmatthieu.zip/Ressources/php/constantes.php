<?php
// Database constants.
define('DB_USER', 'comweb_project');
define('DB_PASSWORD', 'tcejorp_bewmoc_isen29');
define('DB_NAME', 'comweb_project');
define('DB_SERVER', 'localhost');
define('DB_PORT', '3306');
