<?php
/**
 * \\Author: Thibault Napoléon "Imothep"
 * \\Company: ISEN Yncréa Ouest
 * \\Email: thibault.napoleon@isen-ouest.yncrea.fr
 * \\Created Date: 22-Jan-2018 - 14:18:14
 * \\Last Modified: 13-Dec-2019 - 22:10:32
 */

  // Database constants.
  define('DB_USER', 'comweb_tp');
  define('DB_PASSWORD', 'pt_bewmoc_isen29');
  define('DB_NAME', 'comweb_tp');
  define('DB_SERVER', 'localhost');
?>
