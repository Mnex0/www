<?php
/**
 * \\Author: Thibault Napoléon "Imothep"
 * \\Company: ISEN Ouest
 * \\Email: thibault.napoleon@isen-ouest.yncrea.fr
 * \\Created Date: 22-Jan-2018 - 14:18:14
 * \\Last Modified: 30-Mar-2025 - 23:08:50
 */

  // Database constants.
  define('DB_USER', 'comweb_tp');
  define('DB_PASSWORD', 'pt_bewmoc_isen29');
  define('DB_NAME', 'comweb_tp');
  define('DB_SERVER', 'localhost');
  define('DB_PORT', '3306');
?>
